# Face_Detection_Attendence
A Face recognition based attendance system automates attendance using facial recognition technology. It captures real-time images , identifies individual with pre trained model, and log attendance accurately. It is develop using python tkinter in visual studio code
